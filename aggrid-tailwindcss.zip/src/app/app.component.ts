import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { CellClickedEvent, ColDef, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import * as XLSX from 'xlsx';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  // Each Column Definition results in one Column.
  public columnDefs: ColDef[] = [
    { field: 'athlete', minWidth: 180 },
    { field: 'age' },
    { field: 'country', minWidth: 150 },
    { field: 'year' },
    { field: 'date', minWidth: 130 },
    { field: 'sport', minWidth: 100 },
    { field: 'gold' },
    { field: 'silver' },
    { field: 'bronze' },
    { field: 'total' },
  ];

  // DefaultColDef sets props common to all Columns
  public defaultColDef: ColDef = {
    sortable: true,
    filter: true,
  };

  // Data that gets displayed in the grid
  public rowData$!: any[];

  // For accessing the Grid's API
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  file: any;

  constructor(private http: HttpClient) {}

  // Example load data from server
  onGridReady(params: GridReadyEvent) {
    // this.rowData$ = this.http.get<any[]>(
    //   'https://www.ag-grid.com/example-assets/row-data.json'
    // );
  }

  // Example of consuming Grid Event
  onCellClicked(e: CellClickedEvent): void {
    console.log('cellClicked', e);
  }

  // Example using Grid's API
  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  addfile(event: any) {
    this.file = event.target.files[0];
    this.parseExcel(this.file);
    // let fileReader = new FileReader();
    // fileReader.readAsArrayBuffer(this.file);
    // fileReader.onload = (e) => {
    //   this.arrayBuffer = fileReader.result;
    //   var data = new Uint8Array(this.arrayBuffer);
    //   var arr = new Array();
    //   for (var i = 0; i != data.length; ++i)
    //     arr[i] = String.fromCharCode(data[i]);
    //   var bstr = arr.join('');
    //   var workbook = XLSX.read(bstr, { type: 'binary' });
    //   var first_sheet_name = workbook.SheetNames[0];
    //   var worksheet = workbook.Sheets[first_sheet_name];
    //   console.log(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
    //   var arraylist = XLSX.utils.sheet_to_json(worksheet, { raw: true });
    //   this.filelist = [];
    //   console.log(this.filelist);
    // };
  }

  parseExcel(file: any) {
    var reader = new FileReader();

    reader.onload = (e) => {
      var data = (<any>e.target).result;
      var workbook = XLSX.read(data, {
        type: 'binary',
      });

      //test my way of writing
      // var XL_row_object = XLSX.utils.sheet_to_json(
      //   workbook.Sheets[workbook.SheetNames[0]]
      // );
      // var json_object = JSON.stringify(XL_row_object);
      // console.log(json_object);
      // this.handleJsonData(json_object);

      workbook.SheetNames.forEach((sheetName: any) => {
        // Here is your object
        var XL_row_object = XLSX.utils.sheet_to_json(
          workbook.Sheets[sheetName]
        );
        var json_object = JSON.stringify(XL_row_object);
        console.log(json_object);

        this.handleJsonData(json_object);
      });
    };

    reader.onerror = function (ex) {
      console.log(ex);
    };
    reader.readAsBinaryString(file);
  }
  handleJsonData(jsonData: any) {
    this.rowData$ = JSON.parse(jsonData);
  }
}
